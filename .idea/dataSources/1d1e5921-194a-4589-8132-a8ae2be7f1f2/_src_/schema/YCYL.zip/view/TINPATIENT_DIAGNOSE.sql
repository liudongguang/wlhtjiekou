CREATE VIEW TINPATIENT_DIAGNOSE AS SELECT
    a.JBIDENTITY MRSerialNo,a.jlh RowNo,a.ZDTYPE DiagnoseTypeId,c.name_ DiagnoseType,a.ZLJG SituationId,e.name_ Situation,a.JBZDBM ICD,d.name_ Diagnose
FROM
   T_BNJBZD a,T_BNGENZONG b,Stddiagnosetype_ c,STDDISEASE_ d,Stdtherapyresult_ e
where
   a.zblsh=b.zblsh(+) and a.ZDTYPE=c.code_(+) and a.JBZDBM=d.code_(+) and  a.ZLJG=e.code_(+) and b.BNSZ='11' order by a.jbidentity
/
