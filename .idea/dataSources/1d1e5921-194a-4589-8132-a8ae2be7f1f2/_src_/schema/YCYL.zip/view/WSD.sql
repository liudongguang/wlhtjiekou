CREATE VIEW WSD AS select cytime, kjyyfa as name,cyksbm,count(distinct(base.baidentity)) as sl, '1'as flag from T_BA_BASE base join t_bnsscz ss on base.baidentity(+) = ss.ssidentity join t_bnkjyw kj on ss.ssidentity = kj.kjidentity where base.zzdm='49557184-0' and cyksbm is not null and ssczbs = '11' group by cytime,kjyyfa,cyksbm
union all
select cytime, kjyymd as name,cyksbm,count(distinct(base.baidentity)) as sl,'2' as flag from T_BA_BASE base join t_bnsscz ss on base.baidentity(+) = ss.ssidentity join t_bnkjyw kj on ss.ssidentity = kj.kjidentity where base.zzdm='49557184-0' and cyksbm is not null  and ssczbs = '11' group by cytime,kjyymd,cyksbm
/
