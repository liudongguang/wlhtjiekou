CREATE VIEW VW_KS_DISEASE AS select cytime,cyksbm,zljg as name,count(distinct(base.baidentity)) as count, '1' as flag from T_BA_BASE base
join t_bnjbzd jb on base.baidentity(+)=jb.jbidentity
where base.zzdm = '49557184-0'  group by cytime,cyksbm,zljg
union all
select cytime,cyksbm,cyfhqk as name,count(distinct(base.baidentity)) as count, '2' as flag from T_BA_BASE base
where base.zzdm = '49557184-0'  group by cytime,cyksbm,cyfhqk
union all
select cytime,cyksbm,rycyfhqk as name,count(distinct(base.baidentity)) as count, '3' as flag from T_BA_BASE base
where base.zzdm = '49557184-0'  group by cytime,cyksbm,rycyfhqk
union all
select cytime,cyksbm,shoushuqh as name,count(distinct(base.baidentity)) as count, '4' as flag from T_BA_BASE base
where base.zzdm = '49557184-0'  group by cytime,cyksbm,shoushuqh
union all
select cytime,cyksbm,yxbl as name,count(distinct(base.baidentity)) as count, '5' as flag from T_BA_BASE base
where base.zzdm = '49557184-0'  group by cytime,cyksbm,yxbl
union all
select cytime,cyksbm,lcbl as name,count(distinct(base.baidentity)) as count, '6' as flag from T_BA_BASE base
where base.zzdm = '49557184-0'  group by cytime,cyksbm,lcbl
union all
select cytime,cyksbm,ssbdslblqk as name,count(distinct(base.baidentity)) as count, '7' as flag from T_BA_BASE base
where base.zzdm = '49557184-0'  group by cytime,cyksbm,ssbdslblqk
union all
select cytime,cyksbm,sqshblqk as name,count(distinct(base.baidentity)) as count, '8' as flag from T_BA_BASE base
where base.zzdm = '49557184-0'  group by cytime,cyksbm,sqshblqk
union all
select cytime,cyksbm,lczdsjqk as name,count(distinct(base.baidentity)) as count, '9' as flag from T_BA_BASE base
where base.zzdm = '49557184-0'  group by cytime,cyksbm,lczdsjqk
union all
select cytime,cyksbm,to_char(sxfy) as name,count(distinct(base.baidentity)) as count, '10' as flag from T_BA_BASE base
join t_bnsx sx on base.baidentity(+)=sx.sxidentity
where base.zzdm = '49557184-0'  group by cytime,cyksbm,sxfy
union all
select cytime,cyksbm,to_char(shuyefy) as name,count(distinct(base.baidentity)) as count, '11' as flag from T_BA_BASE base
join t_fzgl zg on base.baidentity(+) = zg.bnidentity
where base.zzdm = '49557184-0'  group by cytime,cyksbm,shuyefy
union all
select cytime,cyksbm,sxtype as name,count(distinct(base.baidentity)) as count, '12' as flag from T_BA_BASE base
join t_bnsx sx on base.baidentity(+)=sx.sxidentity
where base.zzdm = '49557184-0'  group by cytime,cyksbm,sxtype
union all
select cytime,cyksbm,ycly as name,count(distinct(base.baidentity)) as count, '13' as flag from T_BA_BASE base
join t_bnyc yc on base.baidentity(+)=yc.ycidentity
where base.zzdm = '49557184-0'  group by cytime,cyksbm,ycly
union all
select cytime,cyksbm,to_char(ycfq) as name,count(distinct(base.baidentity)) as count, '14' as flag from T_BA_BASE base
join t_bnyc yc on base.baidentity(+)=yc.ycidentity
where base.zzdm = '49557184-0'  group by cytime,cyksbm,ycfq
union all
select cytime,cyksbm,to_char(ycfq) as name,count(distinct(base.baidentity)) as count, '15' as flag from T_BA_BASE base
join t_bnyc yc on base.baidentity(+)=yc.ycidentity
where base.zzdm = '49557184-0'  and ycly like '4%' group by cytime,cyksbm,ycfq
union all
select cytime,cyksbm,ycbw as name,count(distinct(base.baidentity)) as count, '16' as flag from T_BA_BASE base
join (select ycidentity,ycly,regexp_substr(ycbw,'([^,]+)',1,rownum) as ycbw from t_bnyc
connect by rownum<(length(regexp_replace(ycbw,'[^,]',''))+2)) yc
on base.baidentity(+)=yc.ycidentity where base.zzdm = '49557184-0'  group by cytime,cyksbm,ycbw
union all
select cytime,cyksbm,ycbw as name,count(distinct(base.baidentity)) as count, '17' as flag from T_BA_BASE base
join (select ycidentity,ycly,regexp_substr(ycbw,'([^,]+)',1,rownum) as ycbw from t_bnyc
connect by rownum<(length(regexp_replace(ycbw,'[^,]',''))+2)) yc on base.baidentity(+)=yc.ycidentity
where base.zzdm = '49557184-0'  and ycly like '4%' group by cytime,cyksbm,ycbw
union all
select cytime,cyksbm,zcddyy as name,count(distinct(base.baidentity)) as count, '18' as flag from T_BA_BASE base
join t_bnynddzc zc on base.baidentity(+)=zc.ynidentity
where base.zzdm = '49557184-0'  group by cytime,cyksbm,zcddyy
union all
select cytime,cyksbm,zzddcd as name,count(distinct(base.baidentity)) as count, '19' as flag from T_BA_BASE base
join t_bnynddzc zc on base.baidentity(+)=zc.ynidentity
where base.zzdm = '49557184-0'  group by cytime,cyksbm,zzddcd
/
