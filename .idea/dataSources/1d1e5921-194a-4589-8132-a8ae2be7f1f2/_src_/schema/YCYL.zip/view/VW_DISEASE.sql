CREATE VIEW VW_DISEASE AS select cytime,cyksbm,zdrybq,zdtype,zhenduanshunxu,ssczbm,jbzdbm,age_sui,age_month,age_days,lyfs,zrridcard,zhusu,zzjgdm,bazrrtype,bnbiaoshi1,hebing1ssbm,hebing2ssbm,hebing3ssbm,to_char(sex) as name,count(distinct(base.baidentity)) as count, '1' as flag from T_BA_BASE base
join t_bnsscz ss on base.baidentity = ss.ssidentity
join t_bnjbzd jb on base.baidentity = jb.jbidentity
join t_bnzrr zrr on base.id = zrr.zblsh
where base.zzdm = '49557184-0'  group by cytime,cyksbm,zdrybq,zdtype,zhenduanshunxu,ssczbm,jbzdbm,age_sui,age_month,age_days,lyfs,zrridcard,zhusu,zzjgdm,bazrrtype,bnbiaoshi1,hebing1ssbm,hebing2ssbm,hebing3ssbm,sex
union all
select cytime,cyksbm,zdrybq,zdtype,zhenduanshunxu,ssczbm,jbzdbm,age_sui,age_month,age_days,lyfs,zrridcard,zhusu,zzjgdm,bazrrtype,bnbiaoshi1,hebing1ssbm,hebing2ssbm,hebing3ssbm,to_char(binganzhiliang) as name,count(distinct(base.baidentity)) as count, '2' as flag from T_BA_BASE base
join t_bnsscz ss on base.baidentity = ss.ssidentity
join t_bnjbzd jb on base.baidentity = jb.jbidentity
join t_bnzrr zrr on base.id = zrr.zblsh
where base.zzdm = '49557184-0'  group by cytime,cyksbm,zdrybq,zdtype,zhenduanshunxu,ssczbm,jbzdbm,age_sui,age_month,age_days,lyfs,zrridcard,zhusu,zzjgdm,bazrrtype,bnbiaoshi1,hebing1ssbm,hebing2ssbm,hebing3ssbm,binganzhiliang
union all
select cytime,cyksbm,zdrybq,zdtype,zhenduanshunxu,ssczbm,jbzdbm,age_sui,age_month,age_days,lyfs,zrridcard,zhusu,zzjgdm,bazrrtype,bnbiaoshi1,hebing1ssbm,hebing2ssbm,hebing3ssbm,rylj as name,count(distinct(base.baidentity)) count, '3' flag from T_BA_BASE base
join t_bnsscz ss on base.baidentity = ss.ssidentity
join t_bnjbzd jb on base.baidentity = jb.jbidentity
join t_bnzrr zrr on base.id = zrr.zblsh
where base.zzdm = '49557184-0'  group by cytime,cyksbm,zdrybq,zdtype,zhenduanshunxu,ssczbm,jbzdbm,age_sui,age_month,age_days,lyfs,zrridcard,zhusu,zzjgdm,bazrrtype,bnbiaoshi1,hebing1ssbm,hebing2ssbm,hebing3ssbm,rylj
union all
select cytime,cyksbm,zdrybq,zdtype,zhenduanshunxu,ssczbm,jbzdbm,age_sui,age_month,age_days,lyfs,zrridcard,zhusu,zzjgdm,bazrrtype,bnbiaoshi1,hebing1ssbm,hebing2ssbm,hebing3ssbm,rybingqing as name,count(distinct(base.baidentity)) count, '4' flag from T_BA_BASE base
join t_bnsscz ss on base.baidentity = ss.ssidentity
join t_bnjbzd jb on base.baidentity = jb.jbidentity
join t_bnzrr zrr on base.id = zrr.zblsh
where base.zzdm = '49557184-0'  group by cytime,cyksbm,zdrybq,zdtype,zhenduanshunxu,ssczbm,jbzdbm,age_sui,age_month,age_days,lyfs,zrridcard,zhusu,zzjgdm,bazrrtype,bnbiaoshi1,hebing1ssbm,hebing2ssbm,hebing3ssbm,rybingqing
union all
select cytime,cyksbm,zdrybq,zdtype,zhenduanshunxu,ssczbm,jbzdbm,age_sui,age_month,age_days,lyfs,zrridcard,zhusu,zzjgdm,bazrrtype,bnbiaoshi1,hebing1ssbm,hebing2ssbm,hebing3ssbm,lyfs as name,count(distinct(base.baidentity)) count, '5' flag from T_BA_BASE base
join t_bnsscz ss on base.baidentity = ss.ssidentity
join t_bnjbzd jb on base.baidentity = jb.jbidentity
join t_bnzrr zrr on base.id = zrr.zblsh
where base.zzdm = '49557184-0'  group by cytime,cyksbm,zdrybq,zdtype,zhenduanshunxu,ssczbm,jbzdbm,age_sui,age_month,age_days,lyfs,zrridcard,zhusu,zzjgdm,bazrrtype,bnbiaoshi1,hebing1ssbm,hebing2ssbm,hebing3ssbm,lyfs
/
