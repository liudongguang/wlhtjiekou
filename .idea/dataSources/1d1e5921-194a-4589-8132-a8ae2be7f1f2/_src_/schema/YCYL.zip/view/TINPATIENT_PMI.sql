CREATE VIEW TINPATIENT_PMI AS SELECT a.id zblsh,c.name_ OutDepart,d.name_ InDepart,
    a.baidentity MRSerialNo,a.banum MRId,a.name PatiName,a.sex,HUNYIN Marriage,a.ylfs PayPatternId,a.zycs InTimes,to_char(a.RYTIME,'YYYY-MM-DD HH24:MI:SS') InTime,to_char(a.CYTIME,'YYYY-MM-DD HH24:MI:SS') OutTime,a.RYKSBM InDepartId,a.CYKSBM OutDepartId,to_char(a.birthday,'YYYY-MM-DD') birthday
FROM
    t_ba_base a,T_BNGENZONG b,Stdhospitaloffice_ c,Stdhospitaloffice_ d
where a.id=b.zblsh(+) and a.cyksbm=c.code_(+) and a.ryksbm=d.code_(+)   and b.BNSZ='11'
/
