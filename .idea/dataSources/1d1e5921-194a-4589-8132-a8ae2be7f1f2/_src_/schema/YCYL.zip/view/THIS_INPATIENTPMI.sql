CREATE VIEW THIS_INPATIENTPMI AS SELECT
    a.baidentity MRSerialNo,a.banum MRId,a.name PatiName,a.sex,HUNYIN Marriage,a.ylfs PayPatternId,a.zycs InTimes,RYTIME
InTime,a.CYTIME OutTime,a.RYKSBM InDepartId,a.CYKSBM OutDepartId,a.birthday
FROM
    t_ba_base a,T_BNGENZONG b
where a.id=b.zblsh(+) and b.BNSZ='11'
/
