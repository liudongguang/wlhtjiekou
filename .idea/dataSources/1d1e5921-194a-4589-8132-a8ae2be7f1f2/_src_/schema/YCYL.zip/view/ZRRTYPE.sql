CREATE VIEW ZRRTYPE AS SELECT
    code_ cod,name_ name
FROM
Stdmrliableman_
/
