CREATE VIEW TINPATIENT_OPERATION AS SELECT
    a.SSIDENTITY MRSerialNo,a.jlh RowNo,a.SSCZBM ICDCM,c.name_ Operation,to_char(a.SSTARTTIME,'YYYY-MM-DD HH24:MI:SS') OperationDate,a.mzfs AnaesthesiaWayId,d.name_ AnaesthesiaWay,a.QKLEVEL CutGradeId,e.name_ CutGrade,a.YHLEVEL UnionGradeId,f.name_ UnionGrade
from T_BNSSCZ a,T_BNGENZONG b,Stdopsoperation_ c,Stdanaesthesiatype_ d,Stdincisionlevel_ e,Stdcicatrizationtype_ f
where a.zblsh=b.zblsh(+) and a.SSCZBM=c.code_(+) and a.mzfs=d.code_(+) and a.QKLEVEL=e.code_(+) and a.YHLEVEL=f.code_(+) and b.BNSZ=11
/
